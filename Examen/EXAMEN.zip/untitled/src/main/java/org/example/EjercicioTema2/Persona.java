package org.example.EjercicioTema2;

public class Persona {
    public static void main(String[] args) {
        Cuenta c = new Cuenta(40);

    }
}
