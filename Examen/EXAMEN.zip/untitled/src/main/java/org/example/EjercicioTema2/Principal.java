package org.example.EjercicioTema2;

public class Principal {
}
