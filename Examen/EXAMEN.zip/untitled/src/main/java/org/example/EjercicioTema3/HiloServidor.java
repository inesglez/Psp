package org.example.EjercicioTema3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class HiloServidor extends Thread {
    BufferedReader fentrada;
    PrintWriter salida;
    Socket socket = null;

    public  HiloServidor(Socket s) throws IOException {
        socket= s;
        //se crean flujos de entrada y de salida con el cliente
        salida = new PrintWriter(socket.getOutputStream(), true);
        fentrada = new BufferedReader( new InputStreamReader(socket.getInputStream()));
    }
    public void run() { // tarea a realizar por el cliente
        String cadena = "";
        System.out.println("cliente iniciado");


    }
}
